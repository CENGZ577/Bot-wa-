hii 

Base Kirbot
Recode : Biiofc
Aku cuma recode aja ya sama ngedit ngedit dikit hehe jngn bully t_t

WhatsApp : https://wa.me/6283148278021

cara ganti foto pembayaran pake qr caranya kalian siapin duku foto qris kalian dengan nama qris.jpg lalu kalian salin trs tempel ke folder gambar klik lewati dan ganti 

males mau ngedit? sini Bii editin 5k aja hehehehe^^
mau tambah list topup/ pulsa kuota? pm aja ya

WhatsApp Ajh Gw Yang Ada Di Atas

Seting Owner di all/database/owner.json
Seting Buat Create Panel all/setting.json
Rename Rename Menu Dll Ada Di appearance.js
#BANTAI MARK😎